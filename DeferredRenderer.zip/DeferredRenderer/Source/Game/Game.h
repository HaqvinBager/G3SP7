#pragma once
#include <vector>

class CModelInstance;
class CVFXInstance;
class CPointLight;

namespace DirectX {
	namespace SimpleMath {
		struct Vector3;
	}
}

class CGame
{
public:
	CGame();
	~CGame();

	void Init();
	void Update(const float dt);

private:
	std::vector<CModelInstance*> myInstances;
	std::vector<CVFXInstance*> myVFX;
	std::vector<CPointLight*> myPointLights;
	std::vector<DirectX::SimpleMath::Vector3> myPointLightPositions;
	std::vector<float> myRadii;
	std::vector<float> mySpeeds;
};

